<?php

return [
    'name' => 0,
    'type' => 1,
    'budget_source' => 2,
    'kshtera' => 3,
    'kharcha' => 4,
    'binyojan_kisim' => 5,
    'sanchalan_garne_ward' => 6,
    'sanchalan_hune_ward' => 7,
    'binyojit_shrot_bakhya' => 8,
    'anudan' => 9,
];