<?php

return [
    'expense_type' => 'expense-type',
    'type' => 'type',
    'topic' => 'topic',
    'sub_topic' => 'topic-area-type',
    'anudan' => 'type-of-grant',
    'type_of_allocation' => 'type-of-plan-allocation',
    'gender' => 'setup_gender',
    'post' => 'setup_positions',
    'samiti_post' => 'samiti-post',
    'setup_nationality' => 'setup_nationality',
    'setup_occupations' => 'setup_occupations',
    'setup_relations' => 'setup_relations',
    'setup_organization_types' => 'setup_organization_types',
    'setup_land_area_types' => 'setup_land_area_types',
    'setup_land_category_types' => 'setup_land_category_types',
    'setup_land_types' => 'setup_land_types',
    'units' => 'setup_unit'
];
