<?php

return [
    'SESSION_EXPIRED' => 'Session expired please enter plan number again',
    'CLIENT_ERROR' => 'Please dont inspect and change element',
    'KARYADESH_MSG' => 'कार्यक्रमको कार्यादेशको हाल्न सफल भयो',
    'SERVER_ERROR' => 'समस्या आयो',
    'MERGE_ERROR' => 'निम्न दर्ता नं को योजना मर्ज भएको छ',
    'INCOMPLETE_FORM_ERROR' => "सम्पूर्ण फारम भरेर मात्र अगाडी बढ्नुहोला",
    'PESKI_INCOMPLETE_FORM_MSG' => "पेस्कीको फारम भरेर मात्र अगाडी बढ्नुहोला",
    'REQUIRED_RUNNING_BILL_PAYMENT_MESSAGE' => "कृपया पत्र छान्नुहोस्"
];
