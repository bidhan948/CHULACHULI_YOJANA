<?php

return [
    // Malpot Profile Validation Message
    'land_type_select' => 'जग्गाको स्वामित्वको किसिम छान्नुहोस्',
    'organization_type' => 'संस्थाको प्रकार छान्नुहोस्',
    'pan_number' => 'इस्थाई लेखा नम्बर लेख्नुहोस',
    'name' => 'पुरा नाम लेख्नुहोस',
    'name_english' => 'पुरा नाम अंग्रेजीमा लेख्नुहोस',

    //Land Details Error

];
